/* 
 * File:   main.cpp
 * Author: Clément
 *
 * Created on 27 mai 2013, 11:42
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

