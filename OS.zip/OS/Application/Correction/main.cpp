/* 
 * File:   main.cpp
 * Author: Clément
 *
 * Created on 25 mars 2013, 09:14
 */

#include <cstdlib>

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {

    return 0;
}

