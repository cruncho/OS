#include "ecran2.h"

void OS_Start()
{
     Efface_Ecran();
     Affiche_Chaine_XY(0,0,">> OS START !!! ");
          
      Affiche_Chaine_XY_Couleur(0,2,"|||",BLEU | LUMINEUX);
      Affiche_Chaine_XY_Couleur(3,2,"|||",BLANC| LUMINEUX);
      Affiche_Chaine_XY_Couleur(6,2,"|||",ROUGE| LUMINEUX);
      
      Affiche_Chaine_XY_Couleur(0,3,"|||",BLEU| LUMINEUX);
      Affiche_Chaine_XY_Couleur(3,3,"|||",BLANC| LUMINEUX);
      Affiche_Chaine_XY_Couleur(6,3,"|||",ROUGE| LUMINEUX);
      
      Affiche_Chaine_XY_Couleur(0,4,"|||",BLEU| LUMINEUX);
      Affiche_Chaine_XY_Couleur(3,4,"|||",BLANC| LUMINEUX);
      Affiche_Chaine_XY_Couleur(6,4,"|||",ROUGE| LUMINEUX);
}
