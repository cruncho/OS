#ifndef _TYPE_H
#define	_TYPE_H
typedef unsigned char  UCHAR;
typedef char           CHAR;
typedef unsigned char  BYTE;
typedef unsigned short UINT16;
typedef short          INT16;
typedef unsigned int   UINT32;
typedef int            INT32;

#endif
