#ifndef INIT_GDT_H
#define	INIT_GDT_H
void Initialisation_GDT();

#endif	/* INIT_GDT_H */

