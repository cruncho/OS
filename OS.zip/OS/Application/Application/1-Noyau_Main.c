#include "Ecran.h"
#include "type.h"
#include "Outils.h"
#include "Info_Boot.h"



void OS_Start(T_BOOT_INFO* P_Info)
{

    
    Efface_Ecran();
    Affiche_Chaine(">>>> BOOT DEF OS V1 Via Grub: ");
    Regle_Couleur(10);
    Affiche_Chaine("Ok\n");
    
    if((P_Info->Flags & BOOT_INFO_MEMOIRE) == BOOT_INFO_MEMOIRE){
        Affiche_Chaine("\nAdresse Basse (640Ko maxi) : ");
        Affiche_Chaine(Entier_Vers_Chaine_Hexa(P_Info->Adresse_Basse,4));
        
        Affiche_Chaine("\nAdresse Haute (au dessus de 1Mo) : ");
        Affiche_Chaine(Entier_Vers_Chaine_Hexa(P_Info->Adresse_Haute,4));
        Affiche_Chaine("\n\tIl y a donc : ");
        
        UINT32 L_Taille_Memoire = P_Info->Adresse_Basse + P_Info->Adresse_Haute + 1024;
        Affiche_Chaine(Entier_Vers_Chaine(L_Taille_Memoire));
        Affiche_Chaine("Ko de memoire -->");
        Affiche_Chaine(Entier_Vers_Chaine(L_Taille_Memoire/1024));
        Affiche_Chaine(" Mo ");
    }
    if((P_Info->Flags & BOOT_LIGNE_COMMANDE) == BOOT_LIGNE_COMMANDE){
        Affiche_Chaine("\nLigne de commande passee au noyau : ");
        Affiche_Chaine((UCHAR*)P_Info->Ligne_De_Commande);
    }
}



/*
     Efface_Ecran();
     Affiche_Chaine_XY(0,0,">> OS START !!! ");
          
      Affiche_Chaine_XY_Couleur(0,2,"|||",BLEU | LUMINEUX);
      Affiche_Chaine_XY_Couleur(3,2,"|||",BLANC| LUMINEUX);
      Affiche_Chaine_XY_Couleur(6,2,"|||",ROUGE| LUMINEUX);
      
      Affiche_Chaine_XY_Couleur(0,3,"|||",BLEU| LUMINEUX);
      Affiche_Chaine_XY_Couleur(3,3,"|||",BLANC| LUMINEUX);
      Affiche_Chaine_XY_Couleur(6,3,"|||",ROUGE| LUMINEUX);
      
      Affiche_Chaine_XY_Couleur(0,4,"|||",BLEU| LUMINEUX);
      Affiche_Chaine_XY_Couleur(3,4,"|||",BLANC| LUMINEUX);
      Affiche_Chaine_XY_Couleur(6,4,"|||",ROUGE| LUMINEUX);
*/