
#ifndef ROUTINES_INTERRUPTION_H
#define	ROUTINES_INTERRUPTION_H


//-----------------------------------------------------------------------------

//------------------------------------------------------------------------------
void CallBack_IRQ0();
void CallBack_IRQ1();
void CallBack_IRQ3();
void CallBack_IRQ4();
void CallBack_IRQ5();
void CallBack_IRQ6();
void CallBack_IRQ7();
void CallBack_IRQ8();
void CallBack_IRQ9();
void CallBack_IRQ10();
void CallBack_IRQ11();
void CallBack_IRQ12();
void CallBack_IRQ13();
void CallBack_IRQ14();
void CallBack_IRQ15();

void CallBack_Defaut();

#endif	/* ROUTINES_INTERRUPTION_H */

