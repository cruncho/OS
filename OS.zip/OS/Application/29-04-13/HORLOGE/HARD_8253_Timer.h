#ifndef HARD_8253_TIMER_H
#define	HARD_8253_TIMER_H

  void Initialisation_8253(UINT16);
  
#endif	/* HARD_8253_TIMER_H */

