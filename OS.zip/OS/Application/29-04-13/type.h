//
#ifndef TYPE_H
#define	TYPE_H



typedef unsigned char   UCHAR;
typedef char            CHAR;
typedef unsigned char    BYTE;
typedef unsigned short   UINT16;
typedef unsigned int    UINT32;
typedef short            INT16;
typedef int               INT32;





#endif	/* TYPE_H */

