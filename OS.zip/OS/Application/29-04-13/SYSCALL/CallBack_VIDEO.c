#include "Ecran.h"
#include "Outils.h"
#include "PLAN_MEMOIRE.h"
#include "Descripteurs.h"
#include "MACRO.h"


/*
 EAX :
 * 0 : effacer l'écran
 *     BH : caractère, BL : attribut
 * 1 : positionner le curseur
 *    BH : X, BL : Y
 * 2 : Affiche un Caractère
 *       BH : caractère, BL : attribut
 * 3 : Affiche Une Chaine
 *      EBX : adresse de la chaine
 */


//##############################################################################
void CallBack_INT_Video(UINT32 P_EAX) // lecture dans la pile
{  
 INITIALISER_DS(SELECTEUR_DATA_NOYAU);
 
UINT16 L_DS;
UINT32 L_Base_Segment_Data;
T_DESCRIPTEUR_SEGMENT* L_Descripteur_Data;

UINT32 L_EBX;

   asm (".intel_syntax noprefix ");
     asm ("mov AX, [EBP+24]");     // dans la pile le registre DS est stocké 24 octets plus haut
     asm ("and AX,0xF8");        // seuls les 13 bits de poids fort représentent un l'index
     asm ("mov %0, AX": "=r" (L_DS));
   asm (".att_syntax noprefix "); 
  
   asm (".intel_syntax noprefix ");
     asm ("mov eax, [EBP+44]"); // dans la pile le registre EBX est stocké 44 octets plus haut
     asm ("mov %0, eax": "=r" (L_EBX));
   asm (".att_syntax noprefix "); 

    L_Descripteur_Data= (T_DESCRIPTEUR_SEGMENT*)(ADRESSE_BASE_DESCRIPTEUR_SEGMENT + L_DS);
     L_Base_Segment_Data = L_Descripteur_Data->Base_Segment_0_15 + 
                          (L_Descripteur_Data->Base_Segment_16_23 << 16) + 
                          (L_Descripteur_Data->Base_Segment_24_31 << 24);
    
         
#ifdef DEBUG_APPEL_SYSTEM
    Affiche_Chaine("-- CallBack_INT_Video --> EAX: ");
    Affiche_Chaine(Entier_Vers_Chaine(P_EAX));
    Affiche_Chaine("    EBX: ");
    Affiche_Chaine(Entier_Vers_Chaine(P_EBX));
     Affiche_Chaine("    ECX: ");
    Affiche_Chaine(Entier_Vers_Chaine(P_ECX));
    
    Affiche_Caractere('\n');
#endif    


    switch (P_EAX) {
        case 0 : Remplir_Ecran( (L_EBX>>8)&0xFF, L_EBX&0xFF); break;
        case 1 : Positionne_Curseur((L_EBX>>8)&0xFF, L_EBX&0xFF); break;
        case 2 : Regle_Couleur(L_EBX&0xFF);
                 Affiche_Caractere((L_EBX>>8)&0xFF); break;
        case 3 : Affiche_Chaine((UCHAR*)(L_Base_Segment_Data + L_EBX)); break;         
        
    }



}
