#ifndef PIC_8259A_H
#define	PIC_8259A_H

 void Inititialisation_8259A();
#endif	/* PIC_8259A_H */

