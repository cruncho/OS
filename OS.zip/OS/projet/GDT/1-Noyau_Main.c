#include "Ecran.h"
#include "Type.h"
#include "Outils.h"
#include "Info_Boot.h"
#include "MACRO.h"
#include "PLAN_MEMOIRE.h"
#include "INIT_IDT.h"
#include "Init_GDT.h"
#include "HARD_8042_Clavier.h"
#include "HARD_8253_Timer.h"
#include "API.h"
#include "Pagination.h"
#include "Allocation_Pages.h"
#include "BitMap_Memoire.h"
#include "Processus.h"
#include "PIC_8259A.h"
#include "Tas_Pages_Systeme.h"
#include "Ordonnanceur.h"
#include "Init_TSS.h"



void OS_Main();

void Affiche_Information_Boot(T_BOOT_INFO* P_Info){
    if((P_Info->Flags & BOOT_INFO_MEMOIRE) == BOOT_INFO_MEMOIRE){
        Regle_Couleur(BLANC); Affiche_Chaine(">>>Memoire detectee : ");
        UINT32 L_Taille_Memoire = P_Info->Adresse_Basse + P_Info->Adresse_Haute + 1024;
        Regle_Couleur(BLEU | LUMINEUX); Affiche_Chaine(Entier_Vers_Chaine(L_Taille_Memoire/1024));
        Affiche_Chaine(" Mo\n");
    }
}
//------------------    aa-----------------------------------------------------------------------------------------------------------------------
void Affiche_Message(UCHAR* P_Message, UCHAR* P_Etat){
    Regle_Couleur(BLANC); Affiche_Chaine(P_Message);
    Positionne_Curseur(78-Taille_Chaine(P_Etat),Donne_Curseur_Y());
    Regle_Couleur(VERT | LUMINEUX); Affiche_Chaine(P_Etat);
    Affiche_Caractere('\n');
}
//-----------------------------------------------------------------------------------------------------------------------------------------

void OS_Start(T_BOOT_INFO* P_Info){ //récupération de l'adresse donnée par EBX
    Efface_Ecran();
    
    Affiche_Message(">>>BOOT DEF OS v1 - 2013 Via GRUB","OK");
    Affiche_Information_Boot(P_Info);
    
    Initialisation_GDT();
    Affiche_Message(">>>Initialisation de la GDT : ", "OK");
    
    //Initialiser le pointeur pile
    //NE PEUT PAS ETRE DANS UNE FONCTION CAR à la sortie d'une fonction le registre ESP est réinitialisé à la valeur précédant l'appel
   // INITIALISE_SS_ESP(SELECTEUR_STACK_NOYAU, DEBUT_STACK_NOYAU)
    OS_Main();
    asm("NOP"); //indispensable afin que l'optimisation de code ne supprime pas la gestion de la pile
}
//---------------------
void Processus_Idle(){
    char* L_Message=(char*)0x0002000;
    
    while(1){
        asm("mov %0, %%ebx; mov $0x02, %%eax; int $0xA0" :: "i" (BLANC));
        asm("mov %0, %%ebx; mov $0x03, %%eax; int $0xA0" :: "m" (L_Message));
        
    }
}


//-----------------------------------------------------------------------------------------------------------------------------------------
void OS_Main(){
   
    char L_Message[20];
    int L_Scan_Code;
    
    Affiche_Message(">>>Initialisation de la Pile (ESP) : ", "Ok");
    Initialisation_IDT();
    Affiche_Message(">>>Initialisation de la IDT : ","OK");
    
    Initialisation_Pagination();
    Affiche_Message(">>>> Initialisation de la pagination : ","OK");

        
    Inititialisation_8259A();
    Affiche_Message(">>>>>Initialisation du PIC 8259A : ", "Ok");
    
    Initialisation_8253(1193);
    Affiche_Message(">>>>>Initialisation du controleur  8253 : ", "Ok");
    
    
    Charge_Processus(0, (UINT32)Processus_Idle ,8);
    Affiche_Message(">>>> Chagement Code process 0","OK");
    Copier_Memoire_Process(0,(BYTE*)BASE_DATA_USER+0x0002000,"Idel\n",6);
    Affiche_Message(">>>> Init data process 0","OK");
    
    /*
    AUTORISE_INTERRUPTION;
      
    
    Allouer_Pages(ADRESSE_BASE_REPERTOIRE_TABLES_DE_PAGES_OS,0x40000000,4);
    Affiche_Chaine("Ecriture dans 0x40000000");
    
    UINT32* Data=(UINT32*)0x40000000;
    
    Affiche_Chaine("\nAppuyer sur une touche pour ecrire a 1 a l'adresse 2 Go \n");
    Attendre_Touche_Relache();
    
    Affiche_Chaine("Ecriture a 0x8000000");
    
    UINT32* Danger=(UINT32*)0x80000000;
    *Danger=0x5555; // erreur
    

    
    //Affiche_Chaine("Appuyer sur une touche pour terminer \n");
   // Attendre_Touche_Relache();
    Affiche_Chaine("FIN");
    
    
    
    
    API_clrscr();
    L_Message[0]='A';
    L_Message[1]='B';
    L_Message[2]='C';
    L_Message[3]=0;
    
    API_puts((char*)L_Message, 6);
    
    L_Scan_Code=API_Attendre_Scan_Code();
    
    Affiche_Chaine("scan code recu via INT 0xA1");
    Affiche_Chaine(Entier_Vers_Chaine(L_Scan_Code));
    Affiche_Chaine("FIN");
    
    
    Affiche_Chaine("Appuyez sur une touche pour lancer une division par 0\n");
    Attendre_Touche_Relache();
    //---------------------------------------------------------------------------------------------------------------------------------------
    //division par zéro...
    
    UINT32 Valeur_1=10;
    UINT32 Valeur_2=0;
    UINT32 Valeur_3;
    
    Valeur_3=Valeur_1/Valeur_2;
    
    Affiche_Chaine("\nResultat : ");
    Affiche_Chaine(Entier_Vers_Chaine(Valeur_3));
    Affiche_Caractere('\n');
    
    Affiche_Chaine("\n\nAppuyez sur une touche pour lancer une violation de protection ou appuyez sur echap pour ignorer cette étape\n");
    UINT16 L_Touche=Attendre_Touche_Relache();
    if(L_Touche != 0x81){
        asm(".intel_syntax noprefix ");
        asm("jmp 0x50:0x100000");
        asm(".att_syntax noprefix \n");
    }
    
    Affiche_Chaine("\n\nAppuyer sur une touche pour lancer codeOP invalide ou appuyer sur echap pour ignorer cette étape\n");
    L_Touche=Attendre_Touche_Relache();
    if(L_Touche != 0x81){
        asm(".intel_syntax noprefix ");
        asm("mov AX,0");
        asm("mov cs,ax");
        asm(".att_syntax noprefix \n");   
    }
*/

    while(1);
}
