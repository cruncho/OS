
#ifndef PAGINATION_H
#define	PAGINATION_H


void Initialisation_Pagination();
void Initialisation_Tables_Pages_Process();
UINT32 Donne_Adresse_Physique(UINT32 P_Adresse_Base_Repertoire,UINT32 P_Virtuelle);


#define DEBUG_PAGINATION


#endif	/* PAGINATION_H */

