
#ifndef COUCHE_USER_H
#define	COUCHE_USER_H

void Charge_Segment_Code(void* P_Code);
#endif	/* COUCHE_USER_H */

