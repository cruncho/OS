
#ifndef TAS_PAGES_SYSTEME_H
#define	TAS_PAGES_SYSTEME_H
//
//UINT32 Reserve_Adresse_Page_System_Libre();
//void Libere_Adresse_Page_System(UINT32 P_Adresse);


#endif	/* TAS_PAGES_SYSTEME_H */

