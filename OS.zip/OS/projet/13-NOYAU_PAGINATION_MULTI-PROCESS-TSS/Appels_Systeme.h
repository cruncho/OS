
#ifndef APPELS_SYSTEME_H
#define	APPELS_SYSTEME_H

#define NOMBRE_APPEL_SYSTEME 2

#define INT_VIDEO   0xA0
#define INT_CLAVIER 0xA1

void Appel_Systeme_Video();
void Appel_Systeme_Clavier();


#endif	/* APPELS_SYSTEME_H */

