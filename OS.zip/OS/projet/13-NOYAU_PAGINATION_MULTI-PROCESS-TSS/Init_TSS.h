
#ifndef INIT_TSS_H
#define	INIT_TSS_H

#include "Descripteurs.h"

void Initialisation_TSS();
extern T_SEGMENT_TSS Le_TSS;

#endif	/* INIT_TSS_H */

