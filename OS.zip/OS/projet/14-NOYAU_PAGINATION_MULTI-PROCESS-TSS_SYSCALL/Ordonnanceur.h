

#ifndef ORDONNANCEUR_H
#define	ORDONNANCEUR_H

extern volatile UINT32 Periode_Ordonnanceur;
extern UINT32 Numero_Process_Courrant;

//#define DEBUG_ORDONNANCEUR

#endif	/* ORDONNANCEUR_H */

