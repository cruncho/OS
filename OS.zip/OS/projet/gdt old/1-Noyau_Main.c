#include "Ecran.h"
#include "Type.h"
#include "Outils.h"
#include "Info_Boot.h"
#include "MACRO.h"
#include "PLAN_MEMOIRE.h"
#include "INIT_IDT.h"
#include "Init_GDT.h"
#include "HARD_8042_Clavier.h"
#include "HARD_8253_Timer.h"
#include "API.h"



void OS_Main();

void Affiche_Information_Boot(T_BOOT_INFO* P_Info){
    if((P_Info->Flags & BOOT_INFO_MEMOIRE) == BOOT_INFO_MEMOIRE){
        Regle_Couleur(BLANC); Affiche_Chaine(">>>Memoire detectee : ");
        UINT32 L_Taille_Memoire = P_Info->Adresse_Basse + P_Info->Adresse_Haute + 1024;
        Regle_Couleur(BLEU | LUMINEUX); Affiche_Chaine(Entier_Vers_Chaine(L_Taille_Memoire/1024));
        Affiche_Chaine(" Mo\n");
    }
}
//------------------    aa-----------------------------------------------------------------------------------------------------------------------
void Affiche_Message(UCHAR* P_Message, UCHAR* P_Etat){
    Regle_Couleur(BLANC); Affiche_Chaine(P_Message);
    Positionne_Curseur(78-Taille_Chaine(P_Etat),Donne_Curseur_Y());
    Regle_Couleur(VERT | LUMINEUX); Affiche_Chaine(P_Etat);
    Affiche_Caractere('\n');
}
//-----------------------------------------------------------------------------------------------------------------------------------------

void OS_Start(T_BOOT_INFO* P_Info){ //récupération de l'adresse donnée par EBX
    Efface_Ecran();
    
    Affiche_Message(">>>BOOT DEF OS v1 - 2013 Via GRUB","OK");
    Affiche_Information_Boot(P_Info);
    
    Initialisation_GDT();
    Affiche_Message(">>>Initialisation de la GDT : ", "OK");
    
    //Initialiser le pointeur pile
    //NE PEUT PAS ETRE DANS UNE FONCTION CAR à la sortie d'une fonction le registre ESP est réinitialisé à la valeur précédant l'appel
    INITIALISE_SS_ESP(SELECTEUR_STACK_NOYAU, DEBUT_STACK_NOYAU)
    OS_Main();
    asm("NOP"); //indispensable afin que l'optimisation de code ne supprime pas la gestion de la pile
}

//-----------------------------------------------------------------------------------------------------------------------------------------
void OS_Main(){
   
    char L_Message[20];
    int L_Scan_Code;
    
    Affiche_Message(">>>Initialisation de la Pile (ESP) : ", "Ok");
    Initialisation_IDT();

    Affiche_Message(">>>Initialisation de la IDT : ","OK");
    
    Inititialisation_8259A();
    Affiche_Message(">>>>>Initialisation du PIC 8259A : ", "Ok");
    
    Initialisation_8253(1193);
    Affiche_Message(">>>>>Initialisation du controleur  8253 : ", "Ok");
    
    AUTORISE_INTERRUPTION;
    
    API_clrscr();
    L_Message[0]='A';
    L_Message[1]='B';
    L_Message[2]='C';
    L_Message[3]=0;
    
    API_puts((char*)L_Message);
    
    L_Scan_Code=API_Attendre_Scan_Code();
    
    Affiche_Chaine("scan code recu via INT 0xA1");
    Affiche_Chaine(Entier_Vers_Chaine(L_Scan_Code));
    Affiche_Chaine("FIN");
    
    /*
    Affiche_Chaine("Appuyez sur une touche pour lancer une division par 0\n");
    Attendre_Touche_Relache();
    //---------------------------------------------------------------------------------------------------------------------------------------
    //division par zéro...
    
    UINT32 Valeur_1=10;
    UINT32 Valeur_2=0;
    UINT32 Valeur_3;
    
    Valeur_3=Valeur_1/Valeur_2;
    
    Affiche_Chaine("\nResultat : ");
    Affiche_Chaine(Entier_Vers_Chaine(Valeur_3));
    Affiche_Caractere('\n');
    
    Affiche_Chaine("\n\nAppuyez sur une touche pour lancer une violation de protection ou appuyez sur echap pour ignorer cette étape\n");
    UINT16 L_Touche=Attendre_Touche_Relache();
    if(L_Touche != 0x81){
        asm(".intel_syntax noprefix ");
        asm("jmp 0x50:0x100000");
        asm(".att_syntax noprefix \n");
    }
    
    Affiche_Chaine("\n\nAppuyer sur une touche pour lancer codeOP invalide ou appuyer sur echap pour ignorer cette étape\n");
    L_Touche=Attendre_Touche_Relache();
    if(L_Touche != 0x81){
        asm(".intel_syntax noprefix ");
        asm("mov AX,0");
        asm("mov cs,ax");
        asm(".att_syntax noprefix \n");   
    }
*/

    while(1);
}
