/* 
 * File:   API.h
 * Author: Clément
 *
 * Created on 6 mai 2013, 09:10
 */

#ifndef API_H
#define	API_H

void API_clrscr();
void API_puts(char* P_Message);

int API_Attendre_Scan_Code();

#endif	/* API_H */

