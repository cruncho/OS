//VIDEO

void API_clrscr(){
    
    asm (" .intel_syntax noprefix");
    asm ("mov eax,0"); // 0 code effacer l ecran
    asm ("mov ebx,0x2007"); // caractere espace en blanc sur fond noir
    asm ("int 0xA0"); 
    asm (" .att_syntax noprefix \n");
}

// ---------------------------------------------------------------

void API_puts(char* P_Message)
{
    asm (" .intel_syntax noprefix");
    asm ("mov ebx,%0":: "r" (P_Message)); // recupere le parametre. adresse de la chaine dans ebx
    asm ("mov eax,3"); //3 : code afficher chaine
    asm ("mov ecx, 0x05");
    asm ("int 0xA0");
    asm (" .att_syntax noprefix \n");  
    
/*
    asm (" mov %0, %%ebx;"
         "mov $0x03, %%eax;"
          "mov $0005, %%ecx;"
          "int $0xA0" :: "m" (P_Message));
*/
}

// CLAVIER 

int API_Attendre_Scan_Code () 
{
    asm (" .intel_syntax noprefix");
    asm ("mov eax,1"); // 1 ::code lecture scan code
    asm ("int 0xA1"); // dans AX il y aura le scan code
    asm (" .att_syntax noprefix \n");
}
