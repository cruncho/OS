
#ifndef PAGINATION_H
#define	PAGINATION_H


void Initialisation_Pagination();

#define DEBUG_PAGINATION


#endif	/* PAGINATION_H */

