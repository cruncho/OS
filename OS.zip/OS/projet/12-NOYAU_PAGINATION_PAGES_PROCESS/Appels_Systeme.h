
#ifndef APPELS_SYSTEME_H
#define	APPELS_SYSTEME_H

#define INT_VIDEO 0xA0

void Appel_Systeme_Video();


#endif	/* APPELS_SYSTEME_H */

