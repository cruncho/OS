
#ifndef ALLOCATION_PAGES_H
#define	ALLOCATION_PAGES_H

void Allouer_Pages(UINT32 P_Base_Tables_pages, UINT32 P_Adresse_Virtuelle, UINT32 P_Nombre_Pages);

#define DEBUG_ALLOCATION

#endif	/* ALLOCATION_PAGES_H */

