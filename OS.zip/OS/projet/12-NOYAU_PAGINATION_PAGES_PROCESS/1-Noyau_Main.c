#include "type.h"
#include "Ecran.h"
#include "Outils.h"
#include "Info_Boot.h"
#include "Init_GDT.h"
#include "Init_IDT.h"
#include "MACRO.h"
#include "PLAN_MEMOIRE.h"
#include "HARD_8042_Clavier.h"
#include "Pagination.h"
//#include "Tas_Pages_Systeme.h"
#include "Allocation_Pages.h"





void OS_Main();

//----------------------------------------------------------------------------        
void Affiche_Informations_Boot(T_BOOT_INFO* P_Info)
{
 if ( (P_Info->Flags & BOOT_INFO_MEMOIRE) == BOOT_INFO_MEMOIRE) {
    Regle_Couleur(BLANC); Affiche_Chaine(">>>Memoire detectee : " );
    UINT32 L_Taille_Memoire =P_Info->Adresse_Basse +P_Info->Adresse_Haute + 1024;
    Regle_Couleur(BLEU| LUMINEUX); Affiche_Chaine(Entier_Vers_Chaine(L_Taille_Memoire/1024) );
    Affiche_Chaine(" Mo \n" );
  }    
}
//----------------------------------------------------------------------------        
void Affiche_Message(UCHAR* P_Message, UCHAR* P_Etat)
{
  Regle_Couleur(BLANC); Affiche_Chaine(P_Message);
  Positionne_Curseur(78-Taille_Chaine(P_Etat),Donne_Curseur_Y());
  Regle_Couleur(VERT | LUMINEUX); Affiche_Chaine(P_Etat);
  Affiche_Caractere('\n');
}
 //---------------------------------------------------------------------------- 



 //---------------------------------------------------------------------------- 
void OS_Start(T_BOOT_INFO* P_Info)
{ 
  Efface_Ecran(); 
  Affiche_Message(">>>BOOT JLV OS V1 - 2011 Via GRUB : ", "OK");
  Affiche_Informations_Boot(P_Info);

  Initialisation_GDT();
  Affiche_Message(">>>Initialisation de la GDT : ","OK");

  //Initialiser le pointeur pile. 
  // NE PAS ETRE DANS UNE FONCTION CAR à la sortie d'une fonction, le regsitre ESP est réinitialisé à la valeur précédant l'appel.
 //  INITIALISE_SS_ESP(SELECTEUR_STACK_NOYAU,DEBUT_STACK_NOYAU); 
  
   
  INITIALISE_SS_ESP(SELECTEUR_STACK_NOYAU, DEBUT_STACK_NOYAU)
   OS_Main();
   asm ("NOP");
}
//------------------------------------------------------------------------------





UINT32* Data;

UINT32 Adresse_Tables_Process_0;
UINT32 Adresse_Tables_Process_1;
UINT32 Compteur_Contexte = 0;
UINT32 Adresse_Table_Courante=ADRESSE_BASE_REPERTOIRE_TABLES_DE_PAGES_OS;

void Change_Contexte() {
    Compteur_Contexte++;
    if (Compteur_Contexte > 1) Compteur_Contexte = 0;
    Affiche_Chaine("\n changement de contexte : ");
    Affiche_Chaine(Entier_Vers_Chaine(Compteur_Contexte));
    Affiche_Chaine("  ==> ");
   // Data =  0x40000000;
    

    switch (Compteur_Contexte) {
        case 0:  Adresse_Table_Courante=Adresse_Tables_Process_0; break; 
        case 1:  Adresse_Table_Courante= Adresse_Tables_Process_1; break;
        default: Adresse_Table_Courante=ADRESSE_BASE_REPERTOIRE_TABLES_DE_PAGES_OS;
    }
    
    INITIALISER_REGISTRE_CR3(Adresse_Table_Courante); ;

    Affiche_Chaine(Entier_Vers_Chaine_Hexa(*(UINT32*)0x40000000, 4));
    Affiche_Chaine("\n");
}
//------------------------------------------------------------------------------
void OS_Main()
{
  Affiche_Message(">>>Initialisation de la Pile (ESP) : ","OK"); 
  Initialisation_IDT();
  Affiche_Message(">>>Initialisation de la IDT : ","OK");  
  
  Initialisation_Pagination();
  Affiche_Message(">>>Initialisation de la Pagination : ","OK");
  Initialisation_Tables_Pages_Process();
  Affiche_Message(">>>Initialisation des tables de pages process : ","OK");
  
  Initialisation_BitMap_Memoire();
  Affiche_Message(">>>Initialisation du BitMap Memoire : ","OK");
  
  Inititialisation_8259A();
  Affiche_Message(">>>Initialisation du PIC 8259A : ","OK");
  Initialisation_8253(1193);
  Affiche_Message(">>>Initialisation du controleur 8253 : ","OK");
 


  INTERDIRE_INTERRUPTION
          

  
  //..........................
  Affiche_Chaine("\nPassage en contexte process 0 \n");
  Adresse_Tables_Process_0 = Donne_Adresse_Tables_Pages_Process(0);
  INITIALISER_REGISTRE_CR3(Adresse_Tables_Process_0);
  Allouer_Pages(Adresse_Tables_Process_0,0x40000000, 10 );
   *(UINT32*)0x40000000=0x5555;

   //..........................
  Affiche_Chaine("\nPassage en contexte process 1 \n");
  Adresse_Tables_Process_1 = Donne_Adresse_Tables_Pages_Process(1);
  INITIALISER_REGISTRE_CR3(Adresse_Tables_Process_1);
  Allouer_Pages(Adresse_Tables_Process_1,0x40000000, 10 );
  *(UINT32*)0x40000000=0x2222;

  //...........................

 INITIALISER_REGISTRE_CR3(ADRESSE_BASE_REPERTOIRE_TABLES_DE_PAGES_OS);
  
 Affiche_Chaine("\nAppuyez sur une touche pour changer de contexte physique \n");
 Attendre_Touche_Relache();
 
 AUTORISE_INTERRUPTION
 
   Affiche_Chaine("\nFIN");
   while(1);
   HALT;

 }





