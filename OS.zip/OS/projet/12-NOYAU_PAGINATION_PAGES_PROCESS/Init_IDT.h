/* 
 * File:   Init_IDT.h
 * Author: Administrateur
 *
 * Created on 24 juillet 2011, 23:06
 */

#ifndef INIT_IDT_H
#define	INIT_IDT_H

  void Initialisation_IDT();
  
#endif	/* INIT_IDT_H */

