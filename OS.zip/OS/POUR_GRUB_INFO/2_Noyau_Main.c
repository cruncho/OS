#include "type.h"
#include "Ecran.h"
#include "Outils.h"
#include "Info_Boot.h"
#include "Init_GDT.h"
#include "MACRO.h"
#include "INIT_IDT.h"
#include "PLAN_MEMOIRE.h"



void Affiche_Informations_Boot(T_BOOT_INFO* P_Info)
{
    if (( P_Info->Flags & BOOT_INFO_MEMOIRE) == ) {
        Regle_Couleur(BLANC); 
        Affiche_Chaine(">>> Memoire detectee : ");
        UINT32 L_TAILLE_MEMOIRE = P_Info->Adresse_Basse+P_Info->Adresse_Haute + 1024;
        Regle_Couleur(BLEU|LUMINEUX);
        Affiche_Chaine(Entier_Vers_Chaine(L_TAILLE_MEMOIRE/1024));
        Affiche_Chaine(" Mo\n");
    }
    
}
// -------------------------------------------------------------------

void Affiche_Message(UCHAR* P_Message, UCHAR* P_Etat)
{
    Regle_Couleur(BLANC);
    Affiche_Chaine(P_Message);
    Positionne_Curseur(78-Taille_Chaine(P_Etat),Donne_Curseur_Y());
    Regle_Couleur(VERT|LUMINEUX);
    Affiche_Caractere('\n');
    
}
// ------------------------------------------- 
void OS_Start(T_BOOT_INFO* P_Info)
{
    Efface_Ecran();
    
    Affiche_Message(">>> BOOT DEF V1.2 2012 Via GRUB : ","OK");
    Affiche_Informations_Boot(P_Info);
    
    Initialisation_GDT();
    Affiche_Message(">>>>> Initialisation de la GDT : ","OK");
    
    INITIALISE_SS_ESP(SELECTEUR_STACK_NOYAU,DEBUT_STACK_NOYAU)
    
    OS_Main();
    
    asm("NOP");
    
}

// ----------------------------
void OS_Main()
{
    Affiche_Message(">>>> Initialisation de la Pile (ESP) : ", "OK");
    while(1);
    
}